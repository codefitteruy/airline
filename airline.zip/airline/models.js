//models.js
const mongoose = require('mongoose');

// ===============
// Database Config
// ===============
const Schema = mongoose.Schema;
//mongoose.connect('mongodb://localhost/airline', {useNewUrlParser: true});

// =======
// Schemas
// =======

const flightsSchema = new Schema({
  status: { 
    type: String,
    enum : ['CONFIRMED','DELAYED', 'CANCELED'],
    default: 'CONFIRMED'
  },
  departed: {type: Boolean, dafault: false },
  origin: {type: mongoose.Schema.Types.ObjectId, ref: 'Airport'},
  destination: {type: mongoose.Schema.Types.ObjectId, ref: 'Airport'},
  plane: {type: mongoose.Schema.Types.ObjectId, ref: 'Plane'},
  arrivingTime: {type: Date},
  departureTime: {type: Date},
  passengers: { type: Number},
  meals: [{type: mongoose.Schema.Types.ObjectId, ref: 'Weather'}],
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now }
  },
  { strict: false }
);

const airportsSchema = new Schema({
  countryIso2: {type: String},
  city: {type: String},
  name: {type: String},
  currentWeather: {type: mongoose.Schema.Types.ObjectId, ref: 'Weather'},
  bussyTimes: [{type: Date}],
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now }
},  
{ strict: false }
);

const planesSchema = new Schema({
  planeType: { type: String},
  seats: { type: Number},
  availableDates: [{type: Date}],
  location: {type: mongoose.Schema.Types.ObjectId, ref: 'Airport'},
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now }
},
{ strict: false }
);

const mealsSchema = new Schema({
  meal: { 
    type: String,
    enum : ['BREAKFAST','LUNCH', 'DINNER'],
    default: 'BREAKFAST'
  },
  typeOfFood: { 
    type: String,
    enum : ['NORMAL', 'VEGAN', 'VEGGIE', 'KOSHER', 'GLUTEN-FREE'],
    default: 'NORMAL'
  },
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now }
},
{ strict: false }
);

const weathersSchema = new Schema({
  condition: {  
    type: String,
    enum : ['GOOD','BAD', 'DANGEROUS'],
    default: 'GOOD'
  },
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now }
},
{ strict: false }
);

const models = {};
models.Flights = mongoose.model('Flight', flightsSchema);
models.Airports = mongoose.model('Airport', airportsSchema);
models.Planes = mongoose.model('Plane', planesSchema);
models.Weathers = mongoose.model('Weather', weathersSchema);
models.Meals = mongoose.model('Meal', mealsSchema);

module.exports = models;