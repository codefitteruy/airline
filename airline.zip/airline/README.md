# AIRLINE

## Cases of use

### Creating a flight

1. On flight creation, first information to be requested should be:
    - Passengers
    - Meals (More than one meal if required)

2. Origin airport needs to be picked.
    - Departure time can be selected by showing times available filtered by bussyTime set in the model (This is thought on premisses that the airports work 24hs, else business hours should be added to the model)

3. Destination airport needs to be picked.
    - Arriving time can be selected by showing times available filtered by bussyTime set in the model (This is thought on premisses that the airports work 24hs, else business hours should be added to the model)
    - Arrival time can be calculated if we have information like airplanes speed, distance calculation between airports, etc

4. After the above information is fulfilled planes with number of seats equal or bigger than passengers should be listed, also filtered by planes available for use between arriving and departure time.

5. On Flight creating Plane and Airports availability are updated

*If Airports or plane are not available, Flight cannot be created*

### Checks to do before flight departure

1. We could set a worker that given flights not yet departed, checks destination and origin's weather to confirm, delay, or cancell a flight.
2. If 20 minutes before departure origin or destination weather is DANGEROUS, flight is updated to DELAYED
3. If 1 hr after departure time and flight has not departured, if origin or destination weather is DANGEROUS, flight is updated to CANCELLED
4. If between the time window set in the two previos points, wheather is GOOD in both origin and destination, flight is updated to CONFIRMED.

### Features to improve system

* We could add crew members (Pilots, Cabin Crew) with availability and planes assignments
* Flight meals could be extended to support amount of meals per type